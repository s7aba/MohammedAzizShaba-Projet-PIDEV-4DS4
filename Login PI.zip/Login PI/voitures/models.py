from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
# Create your models here.
REGION = (
    (0, 'Ariana'),
    (1, 'Beja'),
    (2, 'Ben arous'),
    (3, 'Bizerte'),
    (4, 'Gabes'),
    (5, 'Gafsa'),
    (6, 'Jendouba'),
    (7, 'Kairouan'),
    (8, 'Kasserine'),
    (9, 'Kebili'),
    (10, 'Kef'),
    (11, 'Mahdia'),
    (12, 'Manouba'),
    (13, 'Medenine'),
    (14, 'Monastir'),
    (15, 'Nabeul'),
    (16, 'Sfax'),
    (17, 'Sidi bouzid'),
    (18, 'Siliana'),
    (19, 'Sousse'),
    (20, 'Tataouine'),
    (21, 'Tozeur'),
    (22, 'Tunis'),
    (23, 'Zaghouan'),
)

BOITE = (
    (0, 'Automatique'),
    (1, 'Manuelle'),
)

MARQUE = (
    (0, 'Autre'),
    (1, 'Hyundai'),
    (2, 'Kia'),
    (3, 'Peugeot'),
    (4, 'Volkswagen'),
    (5, 'Renault'),
    (6, 'Toyota'),
    (7, 'Fiat'),
    (8, 'Suzuki'),
    (9, 'Seat'),
    (10, 'Isuzu'),
    (11, 'Dacia'),
    (12, 'MG'),
    (13, 'Chery'),
    (14, 'Mahindra'),
    (15, 'Geely'),
    (16, 'Skoda'),
    (17, 'Ssangyong'),
    (18, 'Great Wall'),
    (19, 'Haval'),
    (20, 'Dongfeng'),
    (21, 'Audi'),
    (22, 'Mercedes-Benz'),
    (23, 'Nissan'),
    (24, 'Ford'),
    (25, 'BMW'),
    (27, 'Honda'),
    (28, 'Tata'),
    (29, 'DFSK'),
    (30, 'Jeep'),
    (31, 'Mazda'),
    (32, 'Chevrolet'),
    (33, 'Land Rover'),
    (34, 'Lada'),
    (35, 'Wallyscar'),
    (36, 'Porsche'),
    (37, 'Alfa Romeo'),
    (38, 'Mitsubishi'),
    (39, 'Jaguar'),
    (40, 'Mini'),
    (41, 'Citroen'),
    (42, 'DS'),
    (43, 'Zotye'),
    (44, 'BAIC'),
    (44, 'BYD'),
    (45, 'Opel'),
    (45, 'Volvo'),
    (46, 'Saab'),
    (47, 'Daihatsu'),
    (48, 'Lexus'),
    (49, 'Cadillac'),
    (50, 'Mega'),
    (51, 'Chrysler'),
    (52, 'Smart'),
    (53, 'Lancia'),
    (54, 'Hummer'),
    (55, 'Dodge'),
    (56, 'Infinity'),
    (57, 'Faw'),
    (58, 'Aro'),
    (59, 'Buick'),
    (60, 'Deawoo'),
    (61, 'AC'),
    (61, 'Acura'),
    (62, 'GMC'),
    (63, 'Aston Martin'),
    (64, 'UFO'),
    (65, 'Bentley'),
    (66, 'Ferrari'),
    (67, 'Lamborghini'),
    (68, 'Masey Ferguson'),
    (69, 'Lincoln'),
    (70, 'Maserati'),
    (71, 'Changhe'),
)

ENERGIE = (
    (0, 'Diesel'),
    (1, 'Electrique'),  
    (2, 'Essence'),
    (3, 'Hybride'),
    (4, 'LPG/GAS'),
)

class Voiture(models.Model):
    marque = models.PositiveIntegerField(choices=MARQUE, null=True)
    energie = models.PositiveIntegerField(choices=ENERGIE, null=True)
    model = models.CharField(max_length=30)
    annee = models.DateField()
    kilometrage = models.PositiveIntegerField()
    region = models.PositiveIntegerField(choices=REGION, null=True)
    boite = models.PositiveIntegerField(choices=BOITE, null=True)
    prix = models.FloatField()
    image = models.ImageField(null=True,blank=True,upload_to = "static/")
    
    puissance = models.PositiveSmallIntegerField()
    class Meta:  
        db_table = "voiture" 
