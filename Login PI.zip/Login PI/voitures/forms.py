from django import forms  
from voitures.models import Voiture  
class voitureForm(forms.ModelForm):  
    class Meta:  
        model = Voiture 
        fields = "__all__"  