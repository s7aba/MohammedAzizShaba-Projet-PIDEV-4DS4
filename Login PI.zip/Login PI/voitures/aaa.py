from django.shortcuts import render
from django.http import JsonResponse
import pandas as pd
import sklearn
from predict.models import FuelResults
from predict.models import PriceResults
from sklearn.preprocessing import LabelEncoder

import warnings
import numpy

warnings.filterwarnings("ignore", category=numpy.VisibleDeprecationWarning)


def index(request):
    marques = numpy.load(r"D:\esprit\Semestre 2\Projet DS\marque_classes_price.npy", allow_pickle=True)
    models = numpy.load(r"D:\esprit\Semestre 2\Projet DS\model_classes.npy", allow_pickle=True)
    categories = numpy.load(r"D:\esprit\Semestre 2\Projet DS\category_classes.npy", allow_pickle=True)

    return render(request, 'landing.html',
                  {'marques': marques,
                   'models': models,
                   'categories': categories})


def fuel_page(request):
    return render(request, 'fuel.html')


def predict_fuel(request):
    if request.POST.get('action') == 'post':
        # Receive data from client
        moteur = str(request.POST.get('moteur')).strip()
        carburant = str(request.POST.get('carburant')).strip()
        marque = str(request.POST.get('marque')).strip()
        cv = int(request.POST.get('cv'))
        year = int(request.POST.get('year'))
        voiture = str(request.POST.get('voiture')).strip()
        # Unpickle model
        model = pd.read_pickle(r"D:\esprit\Semestre 2\Projet DS\conso_model.pickle")

        encode_voiture = numpy.load(r"D:\esprit\Semestre 2\Projet DS\voiture_classes.npy", allow_pickle=True)
        encode_moteur = numpy.load(r"D:\esprit\Semestre 2\Projet DS\moteur_classes.npy", allow_pickle=True)
        encode_marque = numpy.load(r"D:\esprit\Semestre 2\Projet DS\marque_classes.npy", allow_pickle=True)

        voitureencoder = LabelEncoder()
        moteurencoder = LabelEncoder()
        marqueencoder = LabelEncoder()

        voitureencoder.classes_ = encode_voiture
        moteurencoder.classes_ = encode_moteur
        marqueencoder.classes_ = encode_marque

        # Make prediction
        result = model.predict([[moteurencoder.transform([moteur]),
                                 carb(carburant),
                                 marqueencoder.transform([marque]),
                                 cv,
                                 year,
                                 voitureencoder.transform([voiture])]])
        prediction = result[0]

        FuelResults.objects.create(moteur=moteur, carburant=carburant, marque=marque,
                                   cv=cv, year=year, voiture=voiture, prediction=str(prediction))
        return JsonResponse({'result': str(prediction)},
                            safe=False)


def carb(x):
    if x == "Diesel":
        return 1
    elif x == "Essence":
        return 0
    else:
        return 2


def ref1(x):
    if x == "Manuelle":
        return 1
    elif x == "Automatique":
        return 0


def ref2(x):
    if x == "Essence":
        return 1
    elif x == "Diesel":
        return 0


def cat(x):
    if x in range(15000, 40000):
        return "Medium_Range"
    elif x in range(40000, 100000):
        return "High_Range"
    elif x in range(100000, 400000):
        return "Top_Notch_Range"
    else:
        return "Budget_Friendly"


def price_page(request):
    return render(request, 'price.html')


def predict_price(request):
    if request.POST.get('action') == 'post':
        # Receive data from client
        category = str(request.POST.get('category')).strip()
        marque = str(request.POST.get('marque')).strip()
        transmission = str(request.POST.get('transmission')).strip()
        carburant = str(request.POST.get('carburant')).strip()
        annee = int(request.POST.get('year'))
        kilometrage = int(request.POST.get('kilometrage'))
        age = 0

        category = cat(category)
        # Unpickle model
        model = pd.read_pickle(r"D:\esprit\Semestre 2\Projet DS\price_model.pickle")
        scaler = pd.read_pickle(r"D:\esprit\Semestre 2\Projet DS\price_scaler.pickle")

        encode_category = numpy.load(r"D:\esprit\Semestre 2\Projet DS\category_classes.npy", allow_pickle=True)
        encode_marque = numpy.load(r"D:\esprit\Semestre 2\Projet DS\marque_classes_price.npy", allow_pickle=True)

        categoryencoder = LabelEncoder()
        marqueencoder = LabelEncoder()

        categoryencoder.classes_ = encode_category
        marqueencoder.classes_ = encode_marque
        scaled = scaler.transform([[annee, kilometrage, age]])
        # Make prediction
        result = model.predict([[categoryencoder.transform([category]),
                                 marqueencoder.transform([marque]),
                                 ref1(transmission),
                                 ref2(carburant),
                                 scaled[0][0],
                                 scaled[0][1],
                                 scaled[0][2]
                                 ]])
        prediction = result[0]

        PriceResults.objects.create(category=category, marque=marque, transmission=transmission,
                                    carburant=carburant, annee=annee, kilometrage=kilometrage, age=age,
                                    prediction=str(prediction))

        return JsonResponse({'result': str(prediction)},
                            safe=False)


def notfoundpage(request, exception):
    return render(request, '404.html')
