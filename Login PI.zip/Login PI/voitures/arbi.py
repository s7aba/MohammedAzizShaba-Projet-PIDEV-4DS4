#!/usr/bin/env python
# coding: utf-8

# In[34]:


import pandas as pd
import numpy as np
import time
import datetime
from tqdm import tqdm
import matplotlib
import matplotlib.pyplot as plt

#libraries for preprocessing

from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler

#libraries for evaluation
from sklearn.metrics import mean_squared_log_error,r2_score,mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, accuracy_score,recall_score, precision_score, classification_report, confusion_matrix

#libraries for models
from sklearn.linear_model import LinearRegression

from sklearn.linear_model import Ridge
from sklearn.linear_model import LassoCV,RidgeCV
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import Lasso
import xgboost as xgb
from sklearn.neighbors import KNeighborsRegressor

from sklearn.ensemble import RandomForestRegressor

from sklearn.ensemble import BaggingRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR

from sklearn.ensemble import AdaBoostRegressor
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, BaggingRegressor, AdaBoostRegressor, GradientBoostingRegressor
from sklearn import metrics
import warnings
warnings.filterwarnings('ignore')


# In[35]:


df=pd.read_csv("ArgusAuto.csv",sep=",")
df.drop('Unnamed: 0',
  axis='columns', inplace=True)
df


# In[36]:


df.drop('Mois',
  axis='columns', inplace=True)


# In[37]:


df.drop('kilometrageparannée',
  axis='columns', inplace=True)


# In[38]:


#define numeric variable and categorical variable to work separatly on them
num_col=['Kilométrage','Puissance','Année','age']
cat_cols=['Region','Energie','Modèle','Marque','Boite']


# In[39]:


le=preprocessing.LabelEncoder()
df[cat_cols]=df[cat_cols].apply(le.fit_transform)


# In[40]:


#scaling numerical data
norm = StandardScaler()
df['prix'] = np.log(df['prix'])
df['Kilométrage'] = norm.fit_transform(np.array(df['Kilométrage']).reshape(-1,1))
df['Puissance'] = norm.fit_transform(np.array(df['Puissance']).reshape(-1,1))
df['age'] = norm.fit_transform(np.array(df['age']).reshape(-1,1))
#df['EUR'] = norm.fit_transform(np.array(df['EUR']).reshape(-1,1))

#scaling target variable
q1,q3=(df['prix'].quantile([0.25,0.75]))
o1=q1-1.5*(q3-q1)
o2=q3+1.5*(q3-q1)
df=df[(df.prix>=o1) & (df.prix<=o2)]


# In[41]:


"""Reindexing DataFrame so that price feature will at last"""
df=df.reindex(columns=['Energie', 'Kilométrage', 'Puissance','saison','Boite', 'Region', 'Modèle', 'Marque','age','prix'])


# In[44]:


#function to split dataset int training and test
def trainingData(df,n):
    X = df.iloc[:,n]
    y = df.iloc[:,-1:].values.T
    y=y[0]
    X_train,X_test,y_train,y_test=train_test_split(X,y,train_size=0.8,test_size=0.2,random_state=0)
    return (X_train,X_test,y_train,y_test)

X_train,X_test,y_train,y_test=trainingData(df,list(range(len(list(df.columns))-1)))


# In[ ]:





# In[48]:


#model implementation and fitting data
xg_reg = xgb.XGBRegressor(objective ='reg:squarederror', learning_rate = 0.3,
                max_depth = 5, alpha = 1, n_estimators = 300)
xg_reg.fit(X_train,y_train)
y_predXG = xg_reg.predict(X_test)
print(y_predXG)


# In[ ]:




