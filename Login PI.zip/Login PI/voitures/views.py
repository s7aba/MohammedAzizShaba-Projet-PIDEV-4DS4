from django.shortcuts import render,redirect
from voitures.forms import voitureForm  
from voitures.models import Voiture 
import pickle
from django.http import HttpResponse
import datetime
import csv
import pandas as pd
from sklearn.model_selection import train_test_split    
import xgboost
import xgboost as xgb
from sklearn.linear_model import LinearRegression
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn import metrics
import numpy as np


# Create your views here.  
def emp(request):  
    if request.method == "POST":  
        form = voitureForm(request.POST,request.FILES)
        if form.is_valid():  
            try:
               form.save()
               return redirect('/show')
            except:  
                return redirect('/show')  
    else:  
        form = voitureForm()  
    return render(request,'authentication/indexvoiture.html',{'form':form}) 

def show(request):  
    voitures = Voiture.objects.all()  
    return render(request,"authentication/index.html",{'voitures':voitures})

def edit(request, id):  
    voiture = Voiture.objects.get(id=id)  
    return render(request,'authentication/edit.html', {'voiture':voiture})

def update(request, id):  
    voiture = Voiture.objects.get(id=id)  
    form = voitureForm(request.POST, instance = voiture)  
    if form.is_valid():  
        form.save()  
        return redirect("/show")  
    return render(request,'authentication/edit.html', {'voiture': voiture})

def destroy(request, id):  
    voiture = Voiture.objects.get(id=id)  
    voiture.delete()  
    return redirect("/show")  
def result(request):
        data=pd.read_csv("ArgusAuto.csv",sep=",")
        data.drop('Unnamed: 0',axis='columns', inplace=True)
        data.drop('Mois',axis='columns', inplace=True)
        data.drop('kilometrageparannée',axis='columns', inplace=True)
        data.drop('age',axis='columns', inplace=True)
        data.drop('saison',axis='columns', inplace=True)
        data.drop('Date Annonce',axis='columns', inplace=True)
        data.drop('Modèle',axis='columns', inplace=True)
        num_col=['Kilométrage','Puissance','Année']
        cat_cols=['Region','Energie','Marque','Boite']
        le=preprocessing.LabelEncoder()
        data[cat_cols]=data[cat_cols].apply(le.fit_transform)
        norm = StandardScaler()
        data['prix'] = np.log(data['prix'])
        data['Kilométrage'] = norm.fit_transform(np.array(data['Kilométrage']).reshape(-1,1))
        data['Puissance'] = norm.fit_transform(np.array(data['Puissance']).reshape(-1,1))
        
                        
        q1,q3=(data['prix'].quantile([0.25,0.75]))
        o1=q1-1.5*(q3-q1)
        o2=q3+1.5*(q3-q1)
        data=data[(data.prix>=o1) & (data.prix<=o2)]

                    

        """Reindexing DataFrame so that price feature will at last"""
        data=data.reindex(columns=['Energie', 'Kilométrage', 'Puissance','Boite', 'Region','Marque','prix'])


        def trainingData(data,n):
            Y=data ['prix']
            X=data.drop('prix', axis=1)
            X_train, X_test, Y_train, Y_test=train_test_split(X, Y, test_size=.30)
            return (X_train,X_test,Y_train,Y_test)
        X_train,X_test,Y_train,Y_test=trainingData(data,list(range(len(list(data.columns))-1)))
        xg_reg = xgb.XGBRegressor(objective ='reg:squarederror', learning_rate = 0.3,
        max_depth = 5, alpha = 1, n_estimators = 300)
        xg_reg.fit(X_train,Y_train)
        y_predXG = xg_reg.predict(X_test)
        marque = request.POST.get('marque')
        energie = request.POST.get('energie')
        kilometrage = request.POST.get('kilometrage')
        boite = request.POST.get('boite')
        puissance = request.POST.get('puissance')
        annee = request.POST.get('annee')
        region = request.POST.get('region')
        prix = request.POST.get('prix')
        pred=xg_reg.predict(np.array([marque, energie, kilometrage, boite, puissance, region]).reshape(-1,6))
        pred=np.exp(pred)
        pred=pred*2
        
        return render(request, "authentication/indexvoiturepred.html",{'prixes': pred})
    
def result2(request):
    df=pd.read_csv("ArgusAuto.csv",sep=",")
    df.drop('Unnamed: 0',axis='columns', inplace=True)
    df.drop('Mois',axis='columns', inplace=True)
    df.drop('kilometrageparannée',axis='columns', inplace=True)
    df.drop('age',axis='columns', inplace=True)
    df.drop('saison',axis='columns', inplace=True)
    num_col=['Kilométrage','Puissance','Année']
    cat_cols=['Region','Energie','Marque','Boite']
    le=preprocessing.LabelEncoder()
    df[cat_cols]=df[cat_cols].apply(le.fit_transform)
    norm = StandardScaler()
    df['prix'] = np.log(df['prix'])
    df['Kilométrage'] = norm.fit_transform(np.array(df['Kilométrage']).reshape(-1,1))
    df['Puissance'] = norm.fit_transform(np.array(df['Puissance']).reshape(-1,1))
    
                    
    q1,q3=(df['prix'].quantile([0.25,0.75]))
    o1=q1-1.5*(q3-q1)
    o2=q3+1.5*(q3-q1)
    df=df[(df.prix>=o1) & (df.prix<=o2)]

                

    """Reindexing DataFrame so that price feature will at last"""
    df=df.reindex(columns=['Energie', 'Kilométrage', 'Puissance','Boite', 'Region','Marque','prix'])


    def trainingData(df,n):
        y=df['prix']
        X=df
        X_train,X_test,y_train,y_test=train_test_split(X,y,train_size=0.7,test_size=0.3,random_state=0)
        return (X_train,X_test,y_train,y_test)
                    
    X_train,X_test,y_train,y_test=trainingData(df,list(range(len(list(df.columns))-1)))
    xg_reg = xgb.XGBRegressor(objective ='reg:squarederror', learning_rate = 0.3,
    max_depth = 5, alpha = 1, n_estimators = 300)
    xg_reg.fit(X_train,y_train)
    y_predXG = xg_reg.predict(X_test)
    print(y_predXG)

                    
    marque = request.POST.get('marque')
   
    energie = request.POST.get('energie')
    kilometrage = request.POST.get('kilometrage')
    boite = request.POST.get('boite')
    puissance = request.POST.get('puissance')
    annee = request.POST.get('annee')
    region = request.POST.get('region')
    prix = request.POST.get('prix')

                    
    pred=xg_reg.predict(np.array([energie, kilometrage, puissance,annee, boite,region,marque]).reshape(1,-1))
    pred=round(pred[0])
    marque = request.POST.get('marque')
    print(marque)
    energie = request.POST.get('energie')
    kilometrage = request.POST.get('kilometrage')
    boite = request.POST.get('boite')
    puissance = request.POST.get('puissance')
    annee = request.POST.get('annee')
    region = request.POST.get('region')
    prix = request.POST.get('prix')
    X_train,X_test,y_train,y_test=trainingData(df,list(range(len(list(df.columns))-1)))
    xg_reg = xgb.XGBRegressor(objective ='reg:squarederror', learning_rate = 0.3,
    max_depth = 5, alpha = 1, n_estimators = 300)
    xg_reg.fit(X_train,y_train)
    pred=xg_reg.predict(np.array([energie, kilometrage, puissance, annee, boite, region, marque]).reshape(1,-1))
    pred=round(pred[0])
    price="The predicted price is "+str(pred)
    print(price)
    
    return render(request, "authentication/indexvoiturepred.html", {"prixes":price})

def tri(request):
    tri = request.POST.get('marque')
    tri2 = request.POST.get('milage')
    tri3 = request.POST.get('power')
    tri4 = request.POST.get('fuel')
    tri5 = request.POST.get('gear')
    voiture = Voiture.objects.all().filter(marque = tri,boite = tri5 , puissance = tri3, energie = tri4 )  
    return render(request, "authentication/cars.html", {"voitures":voiture })
def stat(request):
    return render(request,"authentication/faq.html")