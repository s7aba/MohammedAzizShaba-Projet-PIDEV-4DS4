EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'argus.autosolutions@gmail.com'
EMAIL_HOST_PASSWORD = 'pidev123'
EMAIL_PORT = 587